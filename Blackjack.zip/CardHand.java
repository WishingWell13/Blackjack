
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import javax.swing.JOptionPane;


public class CardHand{
  int currentTotal;
  ArrayList<Integer> hand;

  public CardHand(){
    hand = new ArrayList<Integer>();
    hand.add((int) (Math.random() * 10 +1));
    hand.add((int) (Math.random() * 10 +1));

    for(int temp: hand){
      currentTotal+=temp;
    }
  }

  public boolean hitAndCheck(){ //returns true if still in game (<=21), false otherwise
    int temp = (int) (Math.random() * 10 + 1);
    currentTotal += temp;
    hand.add(temp);
    return currentTotal <= 21;
  }

  public int getTotal(){
    return currentTotal;
  }

  public void displayHand(){
    JFrame frame = new JFrame("Current Hand");
    //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(new Dimension(400, 100));
    frame.setTitle("Current Hand");

    JButton button = new JButton();
    button.setText(hand.toString());
    button.setBackground(Color.PINK);
    frame.add(button);
    frame.setVisible(true);
  }
  
  public void displayHand(String name){
    JFrame frame = new JFrame("Current Hand for " + name);
    //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(new Dimension(400, 100));
    //frame.setTitle("Current Hand");

    JButton button = new JButton();
    button.setText(hand.toString());
    button.setBackground(Color.PINK);
    frame.add(button);
    frame.setVisible(true);
  }

  public void displayVisibleHand(){
    JFrame frame = new JFrame("Visible Hand for guest");
    //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(new Dimension(400, 100));
    

    JButton button = new JButton();
    ArrayList<Integer> temp = hand;
    temp.remove(0);
    button.setText(temp.toString());
    button.setBackground(Color.PINK);
    frame.add(button);
    frame.setVisible(true);  }
  
  public void displayVisibleHand(String name){
    //JOptionPane.showMessageDialog(null, hand.toString(), "Visible Hand of " + name, JOptionPane.INFORMATION_MESSAGE);
    //System.out.println("Displayed Visible Hand");
    JFrame frame = new JFrame("Visible Hand for " + name);
    //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(new Dimension(400, 100));
   

    JButton button = new JButton();
    ArrayList<Integer> temp = new ArrayList<Integer>();
    for(int i = 1; i<hand.size(); i++){
        temp.add(hand.get(i));
    }
    
    button.setText(temp.toString());
    button.setBackground(Color.PINK);
    frame.add(button);
    frame.setVisible(true);
  }

}