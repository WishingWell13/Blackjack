

/**
 *
 * @author starl
 */
public class Computer{
  CardHand compHand;
  String name;

  public Computer(String name){
    compHand = new CardHand();
    this.name = name;
  }

  public boolean playTurn(int turn){ //return true if still in game, false otherwise
    //compHand.displayVisibleHand();  
    /*if(Math.random()<0){
      compHand.displayVisibleHand(name + " (After folding)");
      return false;
    }else{
       boolean temp = compHand.hitAndCheck();
       if(!temp){
         compHand.displayVisibleHand(name + " (After folding)");
         return false;
       }else{
         compHand.displayVisibleHand(name + " Turn " + turn);
         return true;
       }
    }*/
    
    if(compHand.getTotal() <=17){
        boolean temp = compHand.hitAndCheck();
       if(!temp){
         compHand.displayVisibleHand(name + " (After folding)");
         return false;
       }else{
         compHand.displayVisibleHand(name + " Turn " + turn);
         return true;
       }
    }else{
      compHand.displayVisibleHand(name + " (After folding)");
      return false; 
    }
  }

  public CardHand getHand(){
    return compHand;
  }
  
  public String getName(){
      return name;
  }
}