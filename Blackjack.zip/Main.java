
import java.util.Scanner;
import javax.swing.JOptionPane;


public class Main {
  public static void main(String[] args) {
    System.out.println("Welcome to Blackjack!");
    System.out.println("Your goal is to get as close to 21 as possible, while not going over!");
    System.out.println("Go over, and you lose ;-;.");
    System.out.println("-----------------------------");
    Scanner console = new Scanner(System.in);
    boolean done = false;
    Player player = new Player("Player");
    Computer comp = new Computer("Computer");

    boolean playerPlaying = true;
    boolean compPlaying = true;
    comp.compHand.displayVisibleHand(comp.name + " Turn " + 0);
    int turn = 0;   
    do {
      turn++;
      if(playerPlaying){
        playerPlaying = player.playTurn(turn);
      }else{
        System.out.println("Player Folded");
      }
      if(compPlaying && player.getHand().getTotal()<=21){
        compPlaying = comp.playTurn(turn);
      }
      System.out.println("in loop");
    }while ((playerPlaying || compPlaying) && (player.getHand().getTotal() <= 21 && comp.getHand().getTotal() <= 21));
    
    comp.getHand().displayHand(comp.name + " Final Hand");
    player.getHand().displayHand(player.name + " Final Hand");

    
    //Check to see who wins
    if((player.getHand().getTotal() > 21 && comp.getHand().getTotal() > 21) || (player.getHand().getTotal() == comp.getHand().getTotal())){
        JOptionPane.showMessageDialog(null, "It's a tie!", "Match results", JOptionPane.INFORMATION_MESSAGE);        
    }else if ((player.getHand().getTotal() > 21 && comp.getHand().getTotal() <= 21) || (comp.getHand().getTotal() > player.getHand().getTotal())){
        JOptionPane.showMessageDialog(null, comp.getName() + " wins!", "Match results", JOptionPane.INFORMATION_MESSAGE);
    }else if((player.getHand().getTotal() <= 21 && comp.getHand().getTotal() > 21)|| (player.getHand().getTotal() > comp.getHand().getTotal())){
        JOptionPane.showMessageDialog(null, player.getName() + " wins!", "Match results", JOptionPane.INFORMATION_MESSAGE);
    }else{
        System.out.println("ERROR with calculations!");
    }
  }
}  