

import java.util.Scanner;

public class Player{
  CardHand playerHand;
  String name;

  public Player(String nName){
    playerHand = new CardHand();
    name = nName;
  }

  public boolean playTurn(int turn){
      Scanner console = new Scanner(System.in);
      
      playerHand.displayHand(name + " Turn " + turn + " Start");
      System.out.println("Hit or stay? (Type hit to hit, others will be interpreted as stay)");
      if(console.next().equalsIgnoreCase("Hit")){
        if(!playerHand.hitAndCheck()){
            playerHand.displayHand(name + " Turn " + turn + " Folded");

          return false;
        }else{
            return true;
        }
      }
      return false;
  }
  
  public CardHand getHand(){
      return playerHand;
  }
  
  public String getName(){
      return name;
  }
}
